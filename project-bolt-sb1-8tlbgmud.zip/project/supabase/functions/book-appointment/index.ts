import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

type Booking = {
  doctorId: string;
  date: string;
  time: string;
  patientName: string;
  patientEmail: string;
  patientPhone: string;
  reason: string;
};

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const TIME_RE = /^([01]\d|2[0-3]):[0-5]\d$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_RE = /^\+?[0-9\s()-]{7,20}$/;

function parseBooking(input: unknown): Booking | string {
  if (!input || typeof input !== "object") return "Invalid request.";
  const b = input as Record<string, unknown>;
  const str = (v: unknown, max: number) =>
    typeof v === "string" ? v.trim().slice(0, max) : "";

  const booking: Booking = {
    doctorId: str(b.doctorId, 36),
    date: str(b.date, 10),
    time: str(b.time, 5),
    patientName: str(b.patientName, 100),
    patientEmail: str(b.patientEmail, 200),
    patientPhone: str(b.patientPhone, 20),
    reason: str(b.reason, 500),
  };

  if (!UUID_RE.test(booking.doctorId)) return "Please choose a doctor.";
  if (!DATE_RE.test(booking.date) || Number.isNaN(Date.parse(booking.date)))
    return "Please choose a valid date.";
  if (!TIME_RE.test(booking.time)) return "Please choose a valid time slot.";
  if (booking.patientName.length < 2) return "Please enter the patient's name.";
  if (!EMAIL_RE.test(booking.patientEmail)) return "Please enter a valid email address.";
  if (!PHONE_RE.test(booking.patientPhone)) return "Please enter a valid phone number.";
  return booking;
}

function isoWeekday(date: string): number {
  const day = new Date(`${date}T00:00:00Z`).getUTCDay();
  return day === 0 ? 7 : day;
}

async function sendEmail(to: string, subject: string, text: string): Promise<string> {
  const apiKey = Deno.env.get("RESEND_API_KEY");
  if (!apiKey) return "not_configured";
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      from: Deno.env.get("RESEND_FROM") ?? "MHS <onboarding@resend.dev>",
      to: [to],
      subject,
      text,
    }),
  });
  return res.ok ? "sent" : "failed";
}

async function sendSms(to: string, body: string): Promise<string> {
  const sid = Deno.env.get("TWILIO_ACCOUNT_SID");
  const token = Deno.env.get("TWILIO_AUTH_TOKEN");
  const from = Deno.env.get("TWILIO_FROM_NUMBER");
  if (!sid || !token || !from) return "not_configured";
  const form = new URLSearchParams({ To: to, From: from, Body: body });
  const res = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${btoa(`${sid}:${token}`)}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: form.toString(),
  });
  return res.ok ? "sent" : "failed";
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    if (req.method !== "POST") return json({ error: "Method not allowed." }, 405);

    const parsed = parseBooking(await req.json().catch(() => null));
    if (typeof parsed === "string") return json({ error: parsed }, 400);
    const booking = parsed;

    const today = new Date().toISOString().slice(0, 10);
    if (booking.date < today) return json({ error: "Appointments must be in the future." }, 400);

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const { data: doctor, error: doctorError } = await supabase
      .from("doctors")
      .select("id, name, specialty, working_days, email, phone")
      .eq("id", booking.doctorId)
      .maybeSingle();
    if (doctorError) throw doctorError;
    if (!doctor) return json({ error: "That doctor could not be found." }, 404);

    if (!doctor.working_days.includes(isoWeekday(booking.date))) {
      return json({ error: `${doctor.name} is not available on that day.` }, 409);
    }

    const { data: appointment, error: insertError } = await supabase
      .from("appointments")
      .insert({
        doctor_id: booking.doctorId,
        appointment_date: booking.date,
        slot_time: booking.time,
        patient_name: booking.patientName,
        patient_email: booking.patientEmail,
        patient_phone: booking.patientPhone,
        reason: booking.reason,
      })
      .select("id")
      .single();

    if (insertError) {
      if (insertError.code === "23505") {
        return json({ error: "That time slot was just booked. Please pick another." }, 409);
      }
      throw insertError;
    }

    const when = `${booking.date} at ${booking.time}`;
    const patientText = `Hello ${booking.patientName},\n\nYour appointment with ${doctor.name} (${doctor.specialty}) at MHS is confirmed for ${when}.\n\nReference: ${appointment.id}\n\nThank you for choosing MHS.`;
    const doctorText = `Hello ${doctor.name},\n\nA new appointment has been booked with you for ${when}.\n\nPatient: ${booking.patientName}\nPhone: ${booking.patientPhone}\nEmail: ${booking.patientEmail}\nReason: ${booking.reason || "Not provided"}\n\nReference: ${appointment.id}`;
    const patientSms = `MHS: Your appointment with ${doctor.name} is confirmed for ${when}. Ref: ${appointment.id}`;
    const doctorSms = `MHS: New appointment with patient ${booking.patientName} on ${when}. Ref: ${appointment.id}`;

    const [patientEmailStatus, patientSmsStatus, doctorEmailStatus, doctorSmsStatus] =
      await Promise.all([
        sendEmail(booking.patientEmail, "Your MHS appointment is confirmed", patientText).catch(() => "failed"),
        sendSms(booking.patientPhone, patientSms).catch(() => "failed"),
        doctor.email
          ? sendEmail(doctor.email, "New MHS appointment booked", doctorText).catch(() => "failed")
          : Promise.resolve("no_contact"),
        doctor.phone
          ? sendSms(doctor.phone, doctorSms).catch(() => "failed")
          : Promise.resolve("no_contact"),
      ]);

    return json({
      appointmentId: appointment.id,
      notifications: {
        patientEmail: patientEmailStatus,
        patientSms: patientSmsStatus,
        doctorEmail: doctorEmailStatus,
        doctorSms: doctorSmsStatus,
      },
    });
  } catch (err) {
    console.error("book-appointment failed", err);
    return json({ error: "Something went wrong while booking. Please try again." }, 500);
  }
});
