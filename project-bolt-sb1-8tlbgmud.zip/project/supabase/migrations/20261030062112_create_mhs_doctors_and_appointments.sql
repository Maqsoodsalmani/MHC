/*
# Create doctors and appointments for MHS medical booking

1. New Tables
- `doctors`: public directory of doctors (name, specialty, qualification, experience, bio, photo, weekly working days).
- `appointments`: booked consultations (doctor, date, time slot, patient name, email, phone, reason, status).

2. Security
- Enable RLS on both tables.
- `doctors`: readable by anon and authenticated (public directory). No writes from the browser.
- `appointments`: no direct browser access at all. Patient details stay private; bookings are created by a server function using the service role.
- Function `get_booked_slots`: returns only the booked time slots for a doctor on a date (no patient data), callable by the public booking page.

3. Important Notes
- A unique constraint on (doctor_id, appointment_date, slot_time) prevents two patients from booking the same slot.
- Seed data inserts four sample doctors only if the table is empty.
*/

CREATE TABLE IF NOT EXISTS doctors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  specialty text NOT NULL,
  qualification text NOT NULL,
  experience_years integer NOT NULL DEFAULT 0 CHECK (experience_years >= 0),
  bio text NOT NULL DEFAULT '',
  working_days integer[] NOT NULL DEFAULT '{1,2,3,4,5}',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS appointments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  doctor_id uuid NOT NULL REFERENCES doctors(id) ON DELETE RESTRICT,
  appointment_date date NOT NULL,
  slot_time time NOT NULL,
  patient_name text NOT NULL,
  patient_email text NOT NULL,
  patient_phone text NOT NULL,
  reason text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'confirmed' CHECK (status IN ('confirmed', 'cancelled')),
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT appointments_unique_slot UNIQUE (doctor_id, appointment_date, slot_time)
);

CREATE INDEX IF NOT EXISTS appointments_doctor_date_idx ON appointments (doctor_id, appointment_date);

ALTER TABLE doctors ENABLE ROW LEVEL SECURITY;
ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;

GRANT SELECT ON doctors TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON doctors TO service_role;
GRANT SELECT, INSERT, UPDATE, DELETE ON appointments TO service_role;

DROP POLICY IF EXISTS "public_select_doctors" ON doctors;
CREATE POLICY "public_select_doctors" ON doctors FOR SELECT
  TO anon, authenticated USING (true);

CREATE OR REPLACE FUNCTION get_booked_slots(p_doctor_id uuid, p_date date)
RETURNS SETOF time
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT a.slot_time FROM appointments a
  WHERE a.doctor_id = p_doctor_id
    AND a.appointment_date = p_date
    AND a.status = 'confirmed';
$$;

REVOKE EXECUTE ON FUNCTION get_booked_slots(uuid, date) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION get_booked_slots(uuid, date) TO anon, authenticated;

INSERT INTO doctors (name, specialty, qualification, experience_years, bio, working_days)
SELECT * FROM (VALUES
  ('Dr. Ananya Sharma', 'Cardiologist', 'MD, DM Cardiology', 14, 'Specialises in preventive heart care, hypertension management and cardiac rehabilitation.', ARRAY[1,2,3,4,5,6]),
  ('Dr. Rahul Mehta', 'Dermatologist', 'MBBS, MD Dermatology', 9, 'Treats acne, eczema and hair disorders with a focus on long-term skin health.', ARRAY[1,3,4,5,6]),
  ('Dr. Priya Nair', 'Pediatrician', 'MBBS, DCH, MD Pediatrics', 11, 'Caring for newborns, children and adolescents, including vaccinations and growth checks.', ARRAY[1,2,3,4,5]),
  ('Dr. Arjun Rao', 'Orthopedic Surgeon', 'MS Orthopedics', 17, 'Joint replacement, sports injuries and spine care with minimally invasive techniques.', ARRAY[2,3,4,5,6])
) AS seed(name, specialty, qualification, experience_years, bio, working_days)
WHERE NOT EXISTS (SELECT 1 FROM doctors);
