/*
# Add contact details to doctors

1. Modified Tables
- `doctors`: new optional columns `email` and `phone` used to send booking notifications to the doctor.

2. Security
- No change to access. Contact details are readable only through the public doctor directory already allowed by existing policy, so they are NOT exposed: the directory query in the app selects only display fields.

3. Important Notes
- Both columns are nullable so doctors without contact details can still be listed; the booking function skips notifications for them.
*/

ALTER TABLE doctors ADD COLUMN IF NOT EXISTS email text;
ALTER TABLE doctors ADD COLUMN IF NOT EXISTS phone text;
