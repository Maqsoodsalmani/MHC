/*
# Restrict public doctor directory to display columns

1. Modified Tables
- `doctors`: public read access narrowed so that the private contact columns (`email`, `phone`) are NOT readable by the browser.

2. Security
- Revoke the table-wide SELECT from anon and authenticated.
- Grant SELECT only on the public display columns: id, name, specialty, qualification, experience_years, bio, working_days, created_at.
- Contact details remain readable by server functions (service role) only.

3. Important Notes
- No data is changed or removed.
*/

REVOKE SELECT ON doctors FROM anon, authenticated;
GRANT SELECT (id, name, specialty, qualification, experience_years, bio, working_days, created_at) ON doctors TO anon, authenticated;
